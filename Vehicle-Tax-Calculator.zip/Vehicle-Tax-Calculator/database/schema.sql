-- Database Schema for Vehicle Tax Calculator

DROP DATABASE IF EXISTS vehicle_tax_db;
CREATE DATABASE vehicle_tax_db;
USE vehicle_tax_db;

-- 1. Configuration Table for Tax Rates
-- Stores current duty and tax rates to allow easy updates without code changes.
CREATE TABLE tax_configurations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_type VARCHAR(50) NOT NULL, -- e.g., 'Car', 'Motorcycle', 'Van'
    co2_emissions_min INT DEFAULT 0,   -- Lower bound for CO2 tier
    co2_emissions_max INT DEFAULT 9999,-- Upper bound for CO2 tier
    import_duty_rate DECIMAL(5, 2) NOT NULL, -- Percentage (e.g., 10.00 for 10%)
    vat_rate DECIMAL(5, 2) NOT NULL,         -- Percentage (e.g., 20.00 for 20%)
    excise_duty_base DECIMAL(10, 2) DEFAULT 0.00, -- Flat fee component
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert some default UK-style sample rates
INSERT INTO tax_configurations (vehicle_type, co2_emissions_min, co2_emissions_max, import_duty_rate, vat_rate, excise_duty_base) VALUES
('Car', 0, 100, 10.00, 20.00, 0.00),      -- Low emission
('Car', 101, 150, 10.00, 20.00, 150.00),  -- Medium emission
('Car', 151, 9999, 10.00, 20.00, 500.00), -- High emission (Luxury/Sport)
('Motorcycle', 0, 9999, 6.00, 20.00, 50.00),
('Van', 0, 9999, 10.00, 20.00, 200.00);

-- 2. Calculation Logs Table
-- Stores history of all calculations for audit and review.
CREATE TABLE calculation_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vin VARCHAR(17) NOT NULL,
    vehicle_value DECIMAL(12, 2) NOT NULL,
    vehicle_type VARCHAR(50),
    calculated_duty DECIMAL(12, 2),
    calculated_vat DECIMAL(12, 2),
    calculated_excise DECIMAL(12, 2),
    total_cost DECIMAL(12, 2),
    calculation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Vehicle Data Cache (Optional, simplified for this demo)
-- In a real system, this might be an external API cache.
CREATE TABLE vehicle_data_cache (
    vin VARCHAR(17) PRIMARY KEY,
    make VARCHAR(50),
    model VARCHAR(50),
    year INT,
    fuel_type VARCHAR(30),
    co2_emissions INT,
    category VARCHAR(50) -- Matches tax_configurations.vehicle_type
);

-- Insert some sample vehicle data for testing
INSERT INTO vehicle_data_cache (vin, make, model, year, fuel_type, co2_emissions, category) VALUES
('VIN1234567890ABC', 'Tesla', 'Model 3', 2023, 'Electric', 0, 'Car'),
('VIN0987654321XYZ', 'Ford', 'Mustang', 2022, 'Petrol', 250, 'Car'),
('VIN1122334455QQQ', 'Honda', 'CBR600RR', 2021, 'Petrol', 120, 'Motorcycle');
