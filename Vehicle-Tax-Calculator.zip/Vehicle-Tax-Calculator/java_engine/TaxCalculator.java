
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TaxCalculator {

    public static void main(String[] args) {
        try {
            // Read input from Stdin
            Scanner scanner = new Scanner(System.in);
            StringBuilder jsonInput = new StringBuilder();
            while (scanner.hasNextLine()) {
                jsonInput.append(scanner.nextLine());
            }
            scanner.close();

            String input = jsonInput.toString();
            if (input.isEmpty()) {
                System.err.println("Error: Empty input");
                System.exit(1);
            }

            // Parse JSON (Simple Regex implementation to avoid dependencies)
            double vehicleValue = getDouble(input, "vehicleValue");
            double importDutyRate = getDouble(input, "importDutyRate");
            double vatRate = getDouble(input, "vatRate");
            double exciseDutyBase = getDouble(input, "exciseDutyBase");

            // Calculate Duties and Taxes
            // 1. Import Duty
            double importDuty = vehicleValue * (importDutyRate / 100.0);

            // 2. VAT (Value Added Tax)
            // UK VAT is calculated on the (Vehicle Value + Import Duty)
            double vatableAmount = vehicleValue + importDuty;
            double vat = vatableAmount * (vatRate / 100.0);

            // 3. Excise Duty (Vehicle Tax)
            // In this logic, we use the base passed from Python which looked up the CO2 tier
            double exciseDuty = exciseDutyBase;

            // 4. Total Calculation
            double totalTax = importDuty + vat + exciseDuty;
            double grandTotal = vehicleValue + totalTax;

            // Output JSON
            // Using String.format to ensure valid JSON output
            String jsonOutput = String.format(
                "{\"importDuty\": %.2f, \"vat\": %.2f, \"exciseDuty\": %.2f, \"totalTax\": %.2f, \"grandTotal\": %.2f}",
                importDuty, vat, exciseDuty, totalTax, grandTotal
            );

            System.out.println(jsonOutput);

        } catch (Exception e) {
            System.err.println("Error in calculation: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    // Helper to extract double value from JSON string using Regex
    private static double getDouble(String json, String key) {
        // Matches "key": 123.45 or "key": 123
        Pattern pattern = Pattern.compile("\"" + key + "\"\\s*:\\s*([0-9.]+)");
        Matcher matcher = pattern.matcher(json);
        if (matcher.find()) {
            return Double.parseDouble(matcher.group(1));
        }
        return 0.0;
    }
}
