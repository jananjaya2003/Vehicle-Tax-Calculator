import os
import json
import shutil
import socket
import subprocess
import sys
import time
import webbrowser
import getpass
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BACKEND_DIR = ROOT / "backend"
FRONTEND_DIR = ROOT / "frontend"
JAVA_DIR = ROOT / "java_engine"
SCHEMA_PATH = ROOT / "database" / "schema.sql"

MYSQL_USER = "root"
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "password")
MYSQL_DATABASE = "vehicle_tax_db"

BACKEND_PORT = 5000
FRONTEND_PORT = 8080

VSCODE_EXTENSIONS = [
    "ms-python.python",
    "mtxr.sqltools",
    "mtxr.sqltools-driver-mysql",
]


def print_step(message):
    print(f"[setup] {message}", flush=True)


def run_command(command, cwd=None, check=True):
    print_step(" ".join(str(part) for part in command))
    return subprocess.run(command, cwd=cwd, check=check)


def wait_for_port(port, host="127.0.0.1", timeout=30):
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(1)
            if sock.connect_ex((host, port)) == 0:
                return True
        time.sleep(0.5)
    return False


def port_is_open(port, host="127.0.0.1"):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        return sock.connect_ex((host, port)) == 0


def find_mysql_exe():
    mysql_path = shutil.which("mysql")
    if mysql_path:
        return mysql_path

    candidates = [
        Path(r"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"),
        Path(r"C:\Program Files\MySQL\MySQL Workbench 8.0 CE\mysql.exe"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return None


def write_vscode_settings(password):
    vscode_dir = ROOT / ".vscode"
    vscode_dir.mkdir(exist_ok=True)

    settings = {
        "sqltools.autoConnectTo": ["Vehicle Tax Local MySQL"],
        "sqltools.connections": [
            {
                "name": "Vehicle Tax Local MySQL",
                "driver": "MySQL",
                "server": "127.0.0.1",
                "port": 3306,
                "database": MYSQL_DATABASE,
                "username": MYSQL_USER,
                "password": password,
                "askForPassword": False,
                "connectionTimeout": 15,
                "previewLimit": 50,
            }
        ],
    }

    (vscode_dir / "settings.json").write_text(
        json.dumps(settings, indent=2) + "\n",
        encoding="utf-8",
    )


def ensure_python_dependencies():
    run_command([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "flask-cors"], cwd=BACKEND_DIR)


def ensure_java_compiled():
    java_file = JAVA_DIR / "TaxCalculator.java"
    class_file = JAVA_DIR / "TaxCalculator.class"
    if not class_file.exists() or class_file.stat().st_mtime < java_file.stat().st_mtime:
        run_command(["javac", "TaxCalculator.java"], cwd=JAVA_DIR)
    else:
        print_step("Java engine already compiled.")


def ensure_vscode_extensions():
    code_path = shutil.which("code")
    if not code_path:
        print_step("VS Code CLI not found. Skipping extension installation.")
        return

    for extension in VSCODE_EXTENSIONS:
        run_command([code_path, "--install-extension", extension, "--force"], cwd=ROOT)


def mysql_exec(mysql_exe, password, sql=None, sql_file=None, capture_output=False):
    command = [mysql_exe, f"-u{MYSQL_USER}", f"-p{password}"]
    if sql is not None:
        command.extend(["-e", sql])
    if sql_file is not None:
        command.extend(["--execute", f"source {sql_file.as_posix()}"])
    return subprocess.run(
        command,
        cwd=ROOT,
        check=True,
        capture_output=capture_output,
        text=True,
    )


def try_mysql_password(mysql_exe, password):
    try:
        result = mysql_exec(
            mysql_exe,
            password,
            sql=f"SHOW DATABASES LIKE '{MYSQL_DATABASE}';",
            capture_output=True,
        )
        return result
    except subprocess.CalledProcessError:
        return None


def resolve_mysql_password(mysql_exe):
    tried = []
    candidates = [MYSQL_PASSWORD]
    if "" not in candidates:
        candidates.append("")

    for candidate in candidates:
        tried.append("(empty)" if candidate == "" else candidate)
        result = try_mysql_password(mysql_exe, candidate)
        if result is not None:
            return candidate, result

    if sys.stdin.isatty():
        manual_password = getpass.getpass("MySQL root password: ")
        if manual_password not in candidates:
            result = try_mysql_password(mysql_exe, manual_password)
            if result is not None:
                return manual_password, result

    attempted = ", ".join(tried)
    raise RuntimeError(
        f"Unable to connect to MySQL as {MYSQL_USER}. Tried passwords: {attempted}. "
        "Set MYSQL_PASSWORD or enter the correct password when prompted."
    )


def ensure_database():
    mysql_exe = find_mysql_exe()
    if not mysql_exe:
        raise RuntimeError(
            "MySQL CLI was not found. Install MySQL Server or add mysql.exe to PATH."
        )

    print_step("Checking MySQL connection.")
    password, result = resolve_mysql_password(mysql_exe)

    if MYSQL_DATABASE not in result.stdout:
        print_step("Database not found. Importing schema.sql.")
        mysql_exec(mysql_exe, password, sql_file=SCHEMA_PATH)
    else:
        print_step("Database already exists.")

    write_vscode_settings(password)
    return password


def start_process(command, cwd):
    return subprocess.Popen(command, cwd=cwd)


def build_backend_command(password):
    runtime_code = (
        "import runpy; "
        f"ns = runpy.run_path(r'{(BACKEND_DIR / 'app.py').as_posix()}', run_name='backend_runtime'); "
        f"ns['DB_CONFIG']['password'] = {password!r}; "
        "ns['app'].run(debug=True, port=5000)"
    )
    return [sys.executable, "-c", runtime_code]


def open_frontend():
    webbrowser.open(f"http://localhost:{FRONTEND_PORT}/index.html")


def main():
    backend_process = None
    frontend_process = None
    try:
        ensure_vscode_extensions()
        ensure_python_dependencies()
        ensure_java_compiled()
        mysql_password = ensure_database()

        if port_is_open(BACKEND_PORT):
            print_step(f"Backend already running on port {BACKEND_PORT}.")
        else:
            print_step("Starting Flask backend.")
            backend_process = start_process(build_backend_command(mysql_password), cwd=ROOT)

        if port_is_open(FRONTEND_PORT):
            print_step(f"Frontend server already running on port {FRONTEND_PORT}.")
        else:
            print_step("Starting frontend web server.")
            frontend_process = start_process([sys.executable, "-m", "http.server", str(FRONTEND_PORT)], cwd=FRONTEND_DIR)

        if not wait_for_port(BACKEND_PORT):
            raise RuntimeError("Backend did not start on port 5000.")
        if not wait_for_port(FRONTEND_PORT):
            raise RuntimeError("Frontend did not start on port 8080.")

        open_frontend()
        print("")
        print("Project is running.")
        print(f"Frontend: http://localhost:{FRONTEND_PORT}/index.html")
        print(f"Backend:  http://localhost:{BACKEND_PORT}")
        print("VS Code MySQL connection: Vehicle Tax Local MySQL")
        print("Press Ctrl+C to stop the servers started by this launcher.")

        while True:
            if backend_process and backend_process.poll() is not None:
                raise RuntimeError("Backend process stopped unexpectedly.")
            if frontend_process and frontend_process.poll() is not None:
                raise RuntimeError("Frontend server stopped unexpectedly.")
            time.sleep(1)
    except KeyboardInterrupt:
        print_step("Stopping services.")
    finally:
        for process in (frontend_process, backend_process):
            if process and process.poll() is None:
                process.terminate()
        for process in (frontend_process, backend_process):
            if process and process.poll() is None:
                process.wait(timeout=10)


if __name__ == "__main__":
    main()
