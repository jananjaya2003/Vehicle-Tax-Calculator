<![CDATA[<div align="center">

# 🚗 UK Vehicle Import Duty & Tax Calculator

**A full-stack application to calculate UK vehicle import duties, VAT, and excise taxes — with real-time VIN decoding, smart price estimation, and vehicle image lookup.**

[![Python](https://img.shields.io/badge/Python-3.x-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Java](https://img.shields.io/badge/Java-JDK%208+-ED8B00?logo=openjdk&logoColor=white)](https://www.oracle.com/java/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0-4479A1?logo=mysql&logoColor=white)](https://www.mysql.com/)
[![Flask](https://img.shields.io/badge/Flask-REST%20API-000000?logo=flask&logoColor=white)](https://flask.palletsprojects.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

</div>

---

## 📋 Table of Contents

- [Overview](#-overview)
- [Architecture](#-architecture)
- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [Prerequisites](#-prerequisites)
- [Setup Instructions](#-setup-instructions)
- [API Reference](#-api-reference)
- [How It Works](#-how-it-works)
- [Sample Test Data](#-sample-test-data)
- [Screenshots](#-screenshots)
- [Future Improvements](#-future-improvements)

---

## 🔍 Overview

This application enables users to estimate the total cost of importing a vehicle into the UK, including:

- **Import Duty** — percentage-based customs duty (typically 6–10%)
- **VAT (Value Added Tax)** — 20% applied on (Vehicle Value + Import Duty)
- **Excise Duty** — a flat-rate fee based on CO₂ emission tiers

Users can look up any vehicle by entering its **17-character VIN (Vehicle Identification Number)**. The system first checks the local MySQL cache, then falls back to the **NHTSA (National Highway Traffic Safety Administration)** public API for global VIN decoding. It also fetches a vehicle image from **Wikipedia / Wikimedia Commons** automatically.

---

## 🏗 Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│                          FRONTEND (Browser)                         │
│                   HTML5 / CSS3 / Vanilla JavaScript                  │
│                                                                      │
│  ┌──────────────┐  ┌──────────────────┐  ┌────────────────────────┐  │
│  │ VIN Lookup   │  │ Duty Calculator  │  │ Tax Calculator         │  │
│  │ + Image Card │  │ (Import Duty)    │  │ (VAT + Excise Duty)    │  │
│  └──────┬───────┘  └────────┬─────────┘  └───────────┬────────────┘  │
│         │                   │                        │               │
└─────────┼───────────────────┼────────────────────────┼───────────────┘
          │  REST API (JSON)  │  X-API-KEY Auth        │
          ▼                   ▼                        ▼
┌──────────────────────────────────────────────────────────────────────┐
│                     BACKEND (Python / Flask)                         │
│                       http://localhost:5000                           │
│                                                                      │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────┐  │
│  │ GET /api/       │  │ POST /api/      │  │ NHTSA External      │  │
│  │ vehicle/<vin>   │  │ calculate       │  │ API Fallback        │  │
│  └────────┬────────┘  └────────┬────────┘  └─────────────────────┘  │
│           │                    │                                      │
│     ┌─────▼─────┐       ┌─────▼──────────────┐                      │
│     │  MySQL DB │       │ Java Subprocess    │                      │
│     │  (Cache)  │       │ TaxCalculator.java │                      │
│     └───────────┘       └────────────────────┘                      │
└──────────────────────────────────────────────────────────────────────┘
          │                        │
          ▼                        ▼
┌─────────────────┐    ┌───────────────────────┐
│   MySQL 8.0     │    │  Java Calculation     │
│                 │    │  Engine               │
│ • tax_configs   │    │                       │
│ • calc_logs     │    │ • Import Duty calc    │
│ • vehicle_cache │    │ • VAT calc            │
│                 │    │ • Excise Duty calc    │
└─────────────────┘    │ • Grand Total         │
                       └───────────────────────┘
```

---

## ✨ Features

### Core Functionality
| Feature | Description |
|---|---|
| **VIN Decoding** | Enter any 17-character VIN to auto-decode make, model, year, fuel type, CO₂ emissions, and estimated price |
| **Import Duty Calculator** | Calculate customs import duty based on vehicle value and type (Car / Van) |
| **Tax Calculator** | Calculate VAT (20%) and excise duty based on CO₂ emission tiers |
| **Grand Total** | Combined view of all import costs at a glance |
| **Auto-Fill Forms** | VIN lookup results automatically populate both calculator forms |

### Smart Price Estimation Engine
The backend implements a sophisticated price estimation algorithm when the external API doesn't provide pricing data:

- **70+ Brand Tiers** — from Dacia (£16k) to Bugatti (£2M), with ultra-luxury, luxury, premium, and mass-market categories
- **Vehicle Category Multipliers** — SUVs (+10%), Vans/Trucks (−15%), standard cars (baseline)
- **Fuel Type Multipliers** — Electric (+25% premium), Hybrid (+10%), Diesel (−5%), Petrol (baseline)
- **Age-Based Depreciation** — 15%/year for years 1–5, 8%/year for years 6–15, 3%/year for years 16+
- **Classic Car Recovery** — vehicles 25+ years old gain up to 60% value recovery

### Vehicle Image Lookup
Multi-strategy image fetching pipeline using free, public APIs:

1. **Wikipedia Article Thumbnails** — searches for the vehicle's Wikipedia article image
2. **Wikimedia Commons File Search** — scans Commons for matching vehicle photos
3. **Broad Commons Search** — relaxed filtering for recent vehicles (≤3 years old)
4. **Brand Fallback** — falls back to the manufacturer's Wikipedia article image

### Security & API Design
- **API Key Authentication** — all endpoints protected with `X-API-KEY` header validation
- **CORS Enabled** — frontend–backend cross-origin communication configured
- **Input Validation** — VIN length verification, numeric input checks, fallback defaults
- **Graceful Error Handling** — friendly error messages for database failures, API timeouts, and invalid VINs

### UI / UX
- **Glassmorphism Design** — frosted glass card effects with smooth shadows
- **Responsive Grid Layout** — side-by-side calculators on desktop, stacked on mobile
- **Loading States** — button spinners and skeleton loaders during API calls
- **Fuel Type Badges** — color-coded badges (🟢 Electric, 🔵 Hybrid, ⚫ Diesel, 🔴 Petrol)
- **Google Fonts (Inter)** — premium typographic system with weights 300–700
- **Micro-Animations** — hover effects, card transforms, image zoom on hover

---

## 🛠 Tech Stack

| Layer | Technology | Purpose |
|---|---|---|
| **Frontend** | HTML5, CSS3, JavaScript (ES6+) | User interface & interaction |
| **Backend** | Python 3.x, Flask, Flask-CORS | REST API server |
| **Calculation Engine** | Java (JDK 8+) | Tax computation logic (subprocess) |
| **Database** | MySQL 8.0 | Tax configurations, vehicle cache, audit logs |
| **External API** | NHTSA vPIC API | VIN decoding for global vehicle lookup |
| **Image API** | Wikipedia / Wikimedia Commons API | Vehicle image retrieval |

---

## 📁 Project Structure

```
Vehicle-Tax-Calculator/
│
├── 📄 README.md                    ← You are here
│
├── 📂 frontend/                    ← Client-side application
│   ├── index.html                  ← Main HTML page
│   ├── styles.css                  ← Full CSS with design system (449 lines)
│   └── script.js                   ← Frontend logic & API integration (406 lines)
│
├── 📂 backend/                     ← Python Flask REST API
│   ├── app.py                      ← API routes, VIN lookup, price estimator (323 lines)
│   └── requirements.txt            ← Python dependencies
│
├── 📂 java_engine/                 ← Java tax calculation engine
│   ├── TaxCalculator.java          ← Source code for duty/VAT/excise calculations
│   └── TaxCalculator.class         ← Compiled bytecode (auto-generated)
│
└── 📂 database/                    ← Database setup
    └── schema.sql                  ← MySQL schema + seed data
```

---

## 📦 Prerequisites

Ensure the following are installed on your system:

| Requirement | Version | Download |
|---|---|---|
| **Python** | 3.8+ | [python.org](https://www.python.org/downloads/) |
| **Java JDK** | 8+ | [oracle.com](https://www.oracle.com/java/technologies/downloads/) |
| **MySQL Server** | 5.7+ / 8.0 | [mysql.com](https://dev.mysql.com/downloads/) |
| **pip** | Latest | Comes with Python |

---

## 🚀 Setup Instructions

### Step 1 — Database Setup

1. Open your MySQL client (Workbench, CLI, phpMyAdmin, etc.).
2. Execute the schema script:

   ```sql
   SOURCE /path/to/Vehicle-Tax-Calculator/database/schema.sql;
   ```

   This creates:
   - `vehicle_tax_db` database
   - `tax_configurations` table with UK-style duty/VAT/excise rates
   - `calculation_logs` table for audit history
   - `vehicle_data_cache` table with 3 sample vehicles

3. **Configure credentials** — open `backend/app.py` and update the `DB_CONFIG` block:

   ```python
   DB_CONFIG = {
       'host': 'localhost',
       'user': 'root',           # ← Your MySQL username
       'password': 'your_pass',  # ← Your MySQL password
       'database': 'vehicle_tax_db'
   }
   ```

### Step 2 — Compile the Java Engine

```bash
cd java_engine
javac TaxCalculator.java
```

This generates `TaxCalculator.class` in the same directory. The Python backend invokes this via `subprocess`.

### Step 3 — Install Python Dependencies & Start the Backend

```bash
cd backend
pip install -r requirements.txt
python app.py
```

The Flask server starts at **http://localhost:5000**.

> **Dependencies installed:** `flask`, `flask-cors`, `mysql-connector-python`, `requests`, `python-dotenv`

### Step 4 — Open the Frontend

Navigate to the `frontend/` directory and open `index.html` in your browser:

- **Option A:** Double-click the file
- **Option B:** Right-click → Open with → Chrome / Edge / Firefox
- **Option C:** Use a local server like `python -m http.server 8080` and visit `http://localhost:8080`

---

## 📡 API Reference

### `GET /api/vehicle/<vin>`

Fetch vehicle details by VIN number.

**Headers:**
| Header | Value |
|---|---|
| `X-API-KEY` | `vehicle-tax-secure-key-123` |

**Response (200 OK):**
```json
{
  "vin": "WBA3A5G59DNP26082",
  "make": "BMW",
  "model": "328i",
  "year": "2013",
  "fuel_type": "Petrol",
  "category": "Car",
  "price": 12450.75,
  "co2_emissions": 160,
  "is_estimated_price": true
}
```

**Error Responses:**
| Status | Description |
|---|---|
| `401` | Missing or invalid API key |
| `404` | Vehicle not found in database or external API |
| `500` | Database connection failure |

---

### `POST /api/calculate`

Calculate import duty, VAT, and excise duty.

**Headers:**
| Header | Value |
|---|---|
| `Content-Type` | `application/json` |
| `X-API-KEY` | `vehicle-tax-secure-key-123` |

**Request Body:**
```json
{
  "vehicle_value": 25000,
  "category": "Car",
  "co2_emissions": 160
}
```

**Response (200 OK):**
```json
{
  "importDuty": 2500.00,
  "vat": 5500.00,
  "exciseDuty": 500.00,
  "totalTax": 8500.00,
  "grandTotal": 33500.00
}
```

---

## ⚙ How It Works

### Calculation Pipeline

```
User enters VIN
       │
       ▼
┌──────────────┐    miss    ┌─────────────────┐    miss    ┌────────────┐
│  MySQL Cache ├───────────►│  NHTSA vPIC API ├───────────►│  404 Error │
│  (local DB)  │            │  (VIN decoding) │            └────────────┘
└──────┬───────┘            └────────┬────────┘
       │ hit                         │ hit
       ▼                             ▼
  Return vehicle data      Smart Price Estimation
  (price from DB)          + CO₂ Estimation
       │                             │
       └──────────┬──────────────────┘
                  ▼
       Auto-fill calculator forms
                  │
                  ▼
       User clicks "Calculate"
                  │
                  ▼
  ┌──────────────────────────────┐
  │  Flask Backend               │
  │  1. Fetch tax rates from DB  │
  │  2. Pass JSON to Java engine │
  └──────────────┬───────────────┘
                 ▼
  ┌──────────────────────────────┐
  │  Java TaxCalculator          │
  │                              │
  │  importDuty = value × rate   │
  │  VAT = (value + duty) × 20% │
  │  excise = CO₂ tier flat fee  │
  │  total = duty + VAT + excise │
  └──────────────┬───────────────┘
                 ▼
         JSON result returned
         to frontend & displayed
```

### Tax Rate Tiers (Default UK-style)

| Vehicle Type | CO₂ Range (g/km) | Import Duty | VAT | Excise Duty |
|---|---|---|---|---|
| Car | 0 – 100 | 10% | 20% | £0 |
| Car | 101 – 150 | 10% | 20% | £150 |
| Car | 151+ | 10% | 20% | £500 |
| Van | 0 – 9999 | 10% | 20% | £200 |

> Tax rates are stored in MySQL and can be updated without code changes.

---

## 🧪 Sample Test Data

Use these VINs for quick testing (pre-loaded in the database):

| VIN | Vehicle | Fuel | CO₂ |
|---|---|---|---|
| `VIN1234567890ABC` | Tesla Model 3 (2023) | Electric | 0 g/km |
| `VIN0987654321XYZ` | Ford Mustang (2022) | Petrol | 250 g/km |
| `VIN1122334455QQQ` | Honda CBR600RR (2021) | Petrol | 120 g/km |

You can also enter **any real-world 17-character VIN** — the system will query the NHTSA API and estimate the price automatically.

---

## 🖼 Screenshots

> Open `frontend/index.html` in your browser after completing the setup to see the full UI, which includes:
> - 🔎 VIN lookup with vehicle image card & fuel badge
> - 📊 Side-by-side Import Duty and Tax calculators
> - 💰 Grand Total section with glassmorphism styling

---

## 🔮 Future Improvements

- [ ] **Environment Variables** — move DB credentials and API keys to `.env` file
- [ ] **User Authentication** — JWT-based login for saving calculation history
- [ ] **PDF Export** — generate downloadable tax summary reports
- [ ] **Exchange Rate Integration** — real-time USD/EUR to GBP conversion
- [ ] **Vehicle History Check** — mileage, accident records, MOT history
- [ ] **Admin Dashboard** — update tax rates via a web interface
- [ ] **Docker Compose** — one-command deployment with containers for Flask, Java, and MySQL
- [ ] **Unit & Integration Tests** — pytest for backend, JUnit for Java engine
- [ ] **Rate Limiting** — throttle API requests to prevent abuse
- [ ] **HTTPS / TLS** — production-ready secure transport

---

<div align="center">

**Built with ❤️ for UK vehicle importers**

*Estimates are based on current UK HMRC guidelines. Final costs may vary.*

</div>
]]>
