import os
import json
import subprocess
import mysql.connector
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

API_KEY = "vehicle-tax-secure-key-123"


def is_motorcycle_type(value):
    """Return True when the provided category/type represents a motorcycle."""
    text = str(value or '').strip().lower()
    return 'motorcycle' in text or 'motorbike' in text or text == 'bike'

def require_api_key(func):
    def wrapper(*args, **kwargs):
        key = request.headers.get('X-API-KEY')
        if key != API_KEY:
            return jsonify({"error": "Unauthorized"}), 401
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

# Database Connection Config
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',       # Update with your MySQL username
    'password': 'root', # Update with your MySQL password
    'database': 'vehicle_tax_db'
}

def get_db_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except mysql.connector.Error as err:
        print(f"Error connecting to database: {err}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Smart vehicle price estimator
# Uses brand tier, vehicle category, fuel type, and age-based depreciation.
# The NHTSA free API does NOT return prices, so this is our best estimate.
# ─────────────────────────────────────────────────────────────────────────────

# Brand base prices (GBP) reflect typical new-car MSRP tiers for UK imports
BRAND_BASE_PRICES = {
    # Ultra-luxury / Supercar
    'FERRARI':    250000, 'LAMBORGHINI': 220000, 'MCLAREN':  180000,
    'BENTLEY':    160000, 'ROLLS-ROYCE': 280000, 'BUGATTI':  2000000,
    'ASTON MARTIN': 140000, 'MASERATI':  90000,
    # Luxury
    'PORSCHE':     90000, 'MERCEDES-BENZ': 60000, 'MERCEDES': 60000,
    'BMW':         50000, 'AUDI':          45000, 'LAND ROVER': 60000,
    'JAGUAR':      55000, 'LEXUS':         45000, 'GENESIS':   40000,
    'CADILLAC':    55000, 'LINCOLN':       45000, 'TESLA':     65000,
    'VOLVO':       40000, 'INFINITI':      40000, 'ACURA':     38000,
    # Premium mid
    'ALFA ROMEO': 35000, 'DS':    33000, 'MINI':    30000,
    'JEEP':       35000, 'DODGE': 32000, 'CHRYSLER': 30000,
    'RAM':        38000, 'GMC':   38000, 'BUICK':   34000,
    'SUBARU':     28000, 'MAZDA': 26000, 'SAAB':    25000,
    # Economy / Mass-market
    'TOYOTA':     27000, 'HONDA':  24000, 'FORD':    25000,
    'VOLKSWAGEN': 28000, 'VW':     28000, 'NISSAN':  23000,
    'HYUNDAI':    22000, 'KIA':    21000, 'SEAT':    22000,
    'SKODA':      23000, 'OPEL':   21000, 'VAUXHALL': 21000,
    'PEUGEOT':    22000, 'RENAULT': 21000, 'CITROEN': 20000,
    'FIAT':       18000, 'DACIA':  16000, 'MITSUBISHI': 23000,
    'SUZUKI':     18000, 'ISUZU':  25000, 'CHEVROLET': 30000,
}

DEFAULT_BASE_PRICE = 25000  # fallback for unknown brands

def estimate_vehicle_price(make: str, model: str, year_str: str,
                           fuel: str, vehicle_type: str) -> float:
    """
    Estimate current UK market value of an imported vehicle.
    Formula: base_price * fuel_multiplier * category_multiplier * depreciation
    """
    import datetime
    current_year = datetime.datetime.now().year

    # 1. Brand base price
    make_upper = (make or '').upper().strip()
    base = BRAND_BASE_PRICES.get(make_upper, DEFAULT_BASE_PRICE)

    # 2. Category multiplier (Car and Van only)
    vt_lower = str(vehicle_type).lower()
    if 'truck' in vt_lower or 'van' in vt_lower or 'mpv' in vt_lower:
        category_mult = 0.85
    elif 'suv' in vt_lower or 'crossover' in vt_lower:
        category_mult = 1.10
    else:
        category_mult = 1.00       # Standard car

    # 3. Fuel type multiplier
    fuel_lower = (fuel or '').lower()
    if 'electric' in fuel_lower:
        fuel_mult = 1.25           # EVs carry a premium
    elif 'hybrid' in fuel_lower:
        fuel_mult = 1.10
    elif 'diesel' in fuel_lower:
        fuel_mult = 0.95           # Slight diesel discount in UK post-2018
    else:
        fuel_mult = 1.00           # Petrol baseline

    # 4. Age-based depreciation
    # Cars lose ~15% per year for first 5 years then ~8% per year after
    try:
        age = max(0, current_year - int(year_str))
    except (ValueError, TypeError):
        age = 5  # assume mid-age if year unknown

    if age == 0:
        depreciation = 1.00
    elif age <= 5:
        depreciation = (0.85 ** age)           # 15%/yr new-to-5-yr
    elif age <= 15:
        depreciation = (0.85 ** 5) * (0.92 ** (age - 5))   # 8%/yr 5-15 yr
    else:
        depreciation = (0.85 ** 5) * (0.92 ** 10) * (0.97 ** (age - 15))  # 3%/yr 15+yr

    # Floor: classic/vintage cars (25+ years) start recovering value
    if age >= 25:
        classic_recovery = 1.0 + min((age - 25) * 0.03, 0.60)  # up to +60% recovery
        depreciation *= classic_recovery

    # Absolute floor so we never show £0
    min_price = 500.0

    estimated = base * category_mult * fuel_mult * depreciation
    return round(max(estimated, min_price), 2)

@app.route('/api/vehicle/<vin>', methods=['GET'])
@require_api_key
def get_vehicle_data(vin):
    """
    Fetches vehicle data based on VIN.
    """
    conn = get_db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500

    cursor = conn.cursor(dictionary=True)
    
    # Query the vehicle cache
    query = "SELECT * FROM vehicle_data_cache WHERE vin = %s"
    cursor.execute(query, (vin,))
    vehicle = cursor.fetchone()
    
    cursor.close()
    conn.close()

    if vehicle:
        if is_motorcycle_type(vehicle.get('category')):
            return jsonify({"error": "Motorcycle details are not supported in this calculator."}), 400
        return jsonify(vehicle)
    
    # FALLBACK: EXTERNAL API LOOKUP
    # If not found locally, try fetching from NHTSA (US/Global) API
    # Note: Free APIs often lack specific UK Tax data (CO2/Price).
    try:
        import requests
        print(f"Searching external API for VIN: {vin}")
        response = requests.get(f"https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/{vin}?format=json")
        if response.status_code == 200:
            data = response.json()
            results = data.get('Results', [])
            
            # Extract relevant fields
            make = next((item['Value'] for item in results if item['Variable'] == 'Make'), 'Unknown')
            model = next((item['Value'] for item in results if item['Variable'] == 'Model'), 'Unknown')
            year = next((item['Value'] for item in results if item['Variable'] == 'Model Year'), 'Unknown')
            fuel = next((item['Value'] for item in results if item['Variable'] == 'Fuel Type - Primary'), 'Petrol')
            vehicle_type = next((item['Value'] for item in results if item['Variable'] == 'Vehicle Type'), 'Car')

            # Clean up data
            if make == 'Unknown' and model == 'Unknown':
                return jsonify({"error": "Vehicle not found in global registry"}), 404

            if is_motorcycle_type(vehicle_type):
                return jsonify({"error": "Motorcycle details are not supported in this calculator."}), 400

            # Map Fuel Type (US to UK terms)
            fuel = fuel.lower()
            if "gasoline" in fuel:
                fuel = "Petrol"
            elif "diesel" in fuel:
                fuel = "Diesel"
            elif "electric" in fuel or "bev" in fuel:
                fuel = "Electric"
            elif "hybrid" in fuel:
                fuel = "Hybrid"
            else:
                fuel = "Petrol" # Default

            # ── Smart price & CO2 estimation ──────────────────────────────────
            est_price = estimate_vehicle_price(make, model, year, fuel, vehicle_type)

            # CO2 estimation (g/km) by fuel type — averaged from UK fleet data
            if fuel == "Electric":
                est_co2 = 0
            elif fuel == "Hybrid":
                est_co2 = 85
            elif fuel == "Diesel":
                est_co2 = 145
            else:  # Petrol
                est_co2 = 160

            # Set category (Car and Van only; bikes default to Car)
            vt_lower = str(vehicle_type).lower()
            if 'truck' in vt_lower or 'van' in vt_lower:
                vehicle_type = 'Van'
            else:
                vehicle_type = 'Car'

            vehicle_data = {
                "vin":               vin,
                "make":              make,
                "model":             model,
                "year":              year,
                "fuel_type":         fuel,
                "category":          vehicle_type,
                "price":             est_price,
                "co2_emissions":     est_co2,
                "is_estimated_price": True   # flag so frontend can show disclaimer
            }
            return jsonify(vehicle_data)
            
    except Exception as e:
        print(f"External API Error: {e}")
    
    return jsonify({"error": "Vehicle not found"}), 404

@app.route('/api/calculate', methods=['POST'])
@require_api_key
def calculate_tax():
    """
    Calculates tax by invoking the Java Calculation Engine.
    """
    data = request.json
    
    # Extract necessary data for calculation
    # We expect: vehicle_value, co2_emissions, vehicle_type
    if not data:
        return jsonify({"error": "No data provided"}), 400
        
    vehicle_value = data.get('vehicle_value', 0)
    co2_emissions = data.get('co2_emissions', 0)
    vehicle_type = data.get('category', 'Car') # Default to Car
    if is_motorcycle_type(vehicle_type):
        return jsonify({"error": "Motorcycle calculations are not supported."}), 400
    
    # Fetch relevant tax rates from Database
    conn = get_db_connection()
    if not conn:
        return jsonify({"error": "Database connection failed"}), 500
        
    cursor = conn.cursor(dictionary=True)
    
    # Find the matching tax rule based on type and CO2
    query = """
        SELECT import_duty_rate, vat_rate, excise_duty_base 
        FROM tax_configurations 
        WHERE vehicle_type = %s 
          AND %s BETWEEN co2_emissions_min AND co2_emissions_max
        LIMIT 1
    """
    cursor.execute(query, (vehicle_type, co2_emissions))
    rates = cursor.fetchone()
    
    cursor.close()
    conn.close()
    
    if not rates:
        # Fallback or error if no rate found
        rates = {'import_duty_rate': 10.0, 'vat_rate': 20.0, 'excise_duty_base': 0.0}

    # Prepare payload for Java Engine
    java_payload = {
        "vehicleValue": float(vehicle_value),
        "co2Emissions": int(co2_emissions),
        "vehicleType": vehicle_type,
        "importDutyRate": float(rates['import_duty_rate']),
        "vatRate": float(rates['vat_rate']),
        "exciseDutyBase": float(rates['excise_duty_base'])
    }
    
    json_input = json.dumps(java_payload)

    # Call Java Logic
    # Assumption: Java compiled class is in ../java_engine/bin or similar.
    # We will compile the Java code to a jar or class file.
    # Command: java -cp ../java_engine TaxCalculator '<json_content>'
    
    java_cp_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'java_engine'))
    
    try:
        # We pass the JSON as a command line argument (escaped properly if needed)
        # Using subprocess with input=... is safer for large JSONs, but limits valid stdin usage in Java.
        # Let's pass via stdin for robustness.
        process = subprocess.Popen(
            ['java', '-cp', java_cp_path, 'TaxCalculator'],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        stdout, stderr = process.communicate(input=json_input)
        
        if process.returncode != 0:
            print(f"Java Error: {stderr}")
            return jsonify({"error": "Calculation engine failed", "details": stderr}), 500
            
        # Parse Java output
        result = json.loads(stdout)
        
        # Save Logs (Optional but good practice)
        # log_calculation(data.get('vin', 'UNKNOWN'), vehicle_value, result)

        return jsonify(result)

    except Exception as e:
        print(f"Server Error: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
