const API_BASE_URL = "http://localhost:5000/api";
const API_KEY = "vehicle-tax-secure-key-123";

// State to hold fetched vehicle data
let currentVehicleData = {};

function ensureVehicleTypeOption(type) {
  const select = document.getElementById("dutyType");
  const normalizedType = String(type || "").trim();
  if (!select || !normalizedType) {
    return;
  }

  const existingOption = Array.from(select.options).find(
    (option) => option.value.toLowerCase() === normalizedType.toLowerCase()
  );

  if (!existingOption) {
    const option = document.createElement("option");
    option.value = normalizedType;
    option.textContent = normalizedType;
    select.appendChild(option);
  }
}

function isMotorcycleVehicle(data) {
  const category = String(data?.category || "").toLowerCase();
  const rawType = String(data?.vehicle_type || "").toLowerCase();
  return (
    category.includes("motorcycle") ||
    category.includes("motorbike") ||
    category === "bike" ||
    rawType.includes("motorcycle") ||
    rawType.includes("motorbike") ||
    rawType === "bike"
  );
}

async function fetchVehicleData() {
  const vin = document.getElementById("vinInput").value.trim();
  if (!vin) {
    alert("Please enter a VIN number.");
    return;
  }
  if (vin.length < 11) {
    alert("VIN number must be at least 11 characters.");
    return;
  }

  // Set button loading state
  const btn = document.getElementById("fetchBtn");
  const btnText = document.getElementById("fetchBtnText");
  const btnSpinner = document.getElementById("fetchBtnSpinner");
  btn.disabled = true;
  btnText.textContent = "Fetching…";
  btnSpinner.classList.remove("hidden");

  // Hide image card while new search runs
  document.getElementById("vehicleImageCard").classList.add("hidden");
  document.getElementById("vehicleDetails").classList.add("hidden");

  try {
    const response = await fetch(`${API_BASE_URL}/vehicle/${vin}`, {
      headers: { "X-API-KEY": API_KEY },
    });
    const data = await response.json();

    if (response.ok) {
      if (isMotorcycleVehicle(data)) {
        alert("Motorcycle details are not supported in this calculator.");
        return;
      }
      currentVehicleData = data;
      populateVehicleDetails(data);
      autoFillForms(data);
      fetchVehicleImage(data);
    } else {
      alert(
        data.error || "Vehicle not found. Please check the VIN and try again."
      );
    }
  } catch (error) {
    console.error("Error fetching vehicle data:", error);
    alert("Failed to connect to the server. Make sure the backend is running.");
  } finally {
    // Restore button state
    btn.disabled = false;
    btnText.textContent = "Fetch Details";
    btnSpinner.classList.add("hidden");
  }
}

/* ---------------------------------------------------------------
   Vehicle Image via Wikimedia Commons API
   Searches for "{year} {make} {model}" images on Commons.
   For recent vehicles (≤3 years old), we skip the year in the
   Wikipedia search since 2024/2025 articles may not exist yet.
--------------------------------------------------------------- */
async function fetchVehicleImage(data) {
  const make = (data.make || "").trim();
  const model = (data.model || "").trim();
  const year = (data.year || "").toString().trim();

  const imageCard = document.getElementById("vehicleImageCard");
  const loadingEl = document.getElementById("vehicleImageLoading");
  const contentEl = document.getElementById("vehicleImageContent");
  const errorEl = document.getElementById("vehicleImageError");
  const imgEl = document.getElementById("vehicleImage");
  const labelEl = document.getElementById("vehicleImgLabel");
  const badgeEl = document.getElementById("vehicleImgBadge");

  // Show the card in loading state
  imageCard.classList.remove("hidden");
  loadingEl.classList.remove("hidden");
  contentEl.classList.add("hidden");
  errorEl.classList.add("hidden");

  if (!make || make === "Unknown") {
    showImageError();
    return;
  }

  // Determine if this is a "recent" vehicle (within 3 years)
  const currentYear = new Date().getFullYear();
  const vehicleYear = parseInt(year, 10);
  const isRecentVehicle = !isNaN(vehicleYear) && currentYear - vehicleYear <= 3;

  // Build search terms – for recent vehicles, put make+model first (no year)
  // because Wikipedia/Commons articles for 2024-2026 models may not exist yet
  // but the base model article (e.g. "Toyota Camry") almost always does.
  let searchTerms;
  if (isRecentVehicle) {
    searchTerms = [
      `${make} ${model}`, // "Toyota Camry" – base model article
      `${make} ${model} automobile`,
      `${year} ${make} ${model}`, // try with year too
      make, // brand fallback
    ];
  } else {
    searchTerms = [
      `${make} ${model}`,
      `${year} ${make} ${model}`,
      `${make} ${model} automobile`,
      make,
    ];
  }
  searchTerms = searchTerms.filter((t) => t.trim().length > 1);

  let imageUrl = null;

  // Strategy 1: Wikipedia article thumbnail
  for (const term of searchTerms) {
    imageUrl = await getWikipediaArticleImage(term);
    if (imageUrl) break;
  }

  // Strategy 2: Wikimedia Commons file search
  if (!imageUrl) {
    for (const term of searchTerms) {
      imageUrl = await searchWikimediaCommonsFile(term);
      if (imageUrl) break;
    }
  }

  // Strategy 3: For recent vehicles (≤3 years), also try Wikimedia Commons
  // category pages for the model name and a broader Commons full-text search
  if (!imageUrl && isRecentVehicle) {
    // Try broader Commons full-text: just "make model" without automobile suffix
    const broadTerms = [`${make} ${model}`, make];
    for (const term of broadTerms) {
      imageUrl = await searchWikimediaCommonsFile(term, true /* broadSearch */);
      if (imageUrl) break;
    }
  }

  // Strategy 4: Final fallback – brand image from Wikipedia manufacturer article
  if (!imageUrl) {
    imageUrl = await getWikipediaArticleImage(make);
  }

  loadingEl.classList.add("hidden");

  if (imageUrl) {
    imgEl.src = imageUrl;
    imgEl.onload = () => {
      contentEl.classList.remove("hidden");
      errorEl.classList.add("hidden");
    };
    imgEl.onerror = () => showImageError();

    // Caption
    labelEl.textContent = [year, make, model].filter(Boolean).join(" ");

    // Fuel badge
    const fuel = (data.fuel_type || "").toLowerCase();
    badgeEl.textContent = data.fuel_type || "";
    badgeEl.className =
      "fuel-badge " +
      (fuel.includes("electric")
        ? "badge-electric"
        : fuel.includes("hybrid")
        ? "badge-hybrid"
        : fuel.includes("diesel")
        ? "badge-diesel"
        : "badge-petrol");
  } else {
    showImageError();
  }

  function showImageError() {
    loadingEl.classList.add("hidden");
    contentEl.classList.add("hidden");
    errorEl.classList.remove("hidden");
  }
}

/**
 * Strategy 1: Fetch the lead/thumbnail image from a Wikipedia article about the vehicle.
 * Wikipedia articles for car models almost always have a photo as their first image.
 */
async function getWikipediaArticleImage(searchTerm) {
  try {
    const query = encodeURIComponent(searchTerm);
    // Search Wikipedia articles (namespace 0 = articles), bumped to 5 results
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${query}&srnamespace=0&srlimit=5&format=json&origin=*`;
    const searchResp = await fetch(searchUrl);
    if (!searchResp.ok) return null;
    const searchJson = await searchResp.json();
    const articles = searchJson?.query?.search || [];

    for (const article of articles) {
      const title = article.title;
      // Skip obvious non-vehicle pages (keep disambiguation only if nothing better)
      if (/list of|category:|file:/i.test(title)) continue;

      // Get the page's lead image via pageimages prop
      const imgUrl = `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(
        title
      )}&prop=pageimages&pithumbsize=800&format=json&origin=*`;
      const imgResp = await fetch(imgUrl);
      if (!imgResp.ok) continue;
      const imgJson = await imgResp.json();
      const pages = imgJson?.query?.pages || {};
      for (const page of Object.values(pages)) {
        const thumb = page?.thumbnail?.source;
        if (thumb) {
          console.log(`[Image] Found via Wikipedia article "${title}":`, thumb);
          return thumb;
        }
      }
    }
    return null;
  } catch (e) {
    console.warn("Wikipedia article image search failed:", e);
    return null;
  }
}

/**
 * Strategy 2: Search Wikimedia Commons for image files matching the vehicle.
 */
/**
 * Strategy 2 & 3: Search Wikimedia Commons for image files matching the vehicle.
 * @param {string} searchTerm - The search query.
 * @param {boolean} broadSearch - If true, loosen filters for broader results.
 */
async function searchWikimediaCommonsFile(searchTerm, broadSearch = false) {
  try {
    const query = encodeURIComponent(searchTerm);
    // Search Commons for files (namespace 6); use 15 results in broad mode
    const limit = broadSearch ? 15 : 8;
    const url = `https://commons.wikimedia.org/w/api.php?action=query&list=search&srsearch=${query}&srnamespace=6&srlimit=${limit}&format=json&origin=*`;
    const resp = await fetch(url);
    if (!resp.ok) return null;
    const json = await resp.json();
    const results = json?.query?.search || [];

    for (const item of results) {
      const title = item.title;
      // Only accept photo-type files
      if (!/\.(jpe?g|png|webp)$/i.test(title)) continue;
      // Skip icons, logos, maps, flags, diagrams — but in broad mode allow more
      const strictFilter =
        /logo|icon|map|flag|diagram|coat_of|arms|badge|emblem|scheme|blueprint|silhouette/i;
      const looseFilter =
        /icon|map|flag|coat_of|arms|scheme|blueprint|silhouette/i;
      if (broadSearch ? looseFilter.test(title) : strictFilter.test(title))
        continue;

      // Resolve the actual image URL via imageinfo API on Commons
      const infoUrl = `https://commons.wikimedia.org/w/api.php?action=query&titles=${encodeURIComponent(
        title
      )}&prop=imageinfo&iiprop=url&iiurlwidth=800&format=json&origin=*`;
      const infoResp = await fetch(infoUrl);
      if (!infoResp.ok) continue;
      const infoJson = await infoResp.json();
      const pages = infoJson?.query?.pages || {};
      for (const page of Object.values(pages)) {
        const thumbUrl =
          page?.imageinfo?.[0]?.thumburl || page?.imageinfo?.[0]?.url;
        if (thumbUrl) {
          console.log(
            `[Image] Found via Wikimedia Commons "${title}":`,
            thumbUrl
          );
          return thumbUrl;
        }
      }
    }
    return null;
  } catch (e) {
    console.warn("Wikimedia Commons search failed:", e);
    return null;
  }
}

function populateVehicleDetails(data) {
  document.getElementById("vehicleMake").textContent = data.make || "-";
  document.getElementById("vehicleModel").textContent = data.model || "-";
  document.getElementById("vehicleYear").textContent = data.year || "-";
  document.getElementById("vehicleFuel").textContent = data.fuel_type || "-";
  document.getElementById("vehicleCO2").textContent =
    data.co2_emissions !== undefined ? data.co2_emissions : "-";

  // Show estimated price with a disclaimer badge if value is computed, not real
  const price = data.price || 25000;
  const valueEl = document.getElementById("vehicleValueDisplay");
  if (data.is_estimated_price) {
    valueEl.innerHTML = `~${formatCurrency(
      price
    )} <span class="est-badge" title="Estimated based on brand, age &amp; fuel type">est.</span>`;
  } else {
    valueEl.textContent = formatCurrency(price);
  }

  document.getElementById("vehicleDetails").classList.remove("hidden");
}

function autoFillForms(data) {
  // Fill Duty Form
  // Assuming we have a price in the data, otherwise use a default or let user enter
  const price = data.price || 25000;
  document.getElementById("dutyValue").value = formatMoneyInputValue(price);
  if (data.category) {
    ensureVehicleTypeOption(data.category);
    document.getElementById("dutyType").value = data.category;
  }

  // Fill Tax Form
  document.getElementById("taxValue").value = formatMoneyInputValue(price);
  if (data.co2_emissions) {
    document.getElementById("taxCO2").value = data.co2_emissions;
  }
  if (data.fuel_type) {
    document.getElementById("taxFuel").value = data.fuel_type;
  }
}

function parseCurrencyInput(inputId, fieldLabel, showAlerts = true) {
  const raw = document.getElementById(inputId).value.trim();
  const normalized = raw.replace(/,/g, "");

  if (!normalized || normalized === ".") {
    if (showAlerts) alert(`Please enter ${fieldLabel}.`);
    return null;
  }

  if (!/^\d*(\.\d*)?$/.test(normalized)) {
    if (showAlerts) alert(`${fieldLabel} must be a valid number.`);
    return null;
  }

  const decimalPart = normalized.split(".")[1] || "";
  if (decimalPart.length > 2) {
    if (showAlerts)
      alert(`${fieldLabel} can have at most 2 decimal places (cents).`);
    return null;
  }

  const value = Number(normalized);
  if (!Number.isFinite(value) || value < 0) {
    if (showAlerts) alert(`${fieldLabel} must be a valid non-negative amount.`);
    return null;
  }

  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function parseWholeNumberInput(inputId, fieldLabel) {
  const raw = document.getElementById(inputId).value.trim();
  if (!/^\d+$/.test(raw)) {
    alert(`${fieldLabel} must be a whole number.`);
    return null;
  }
  return Number(raw);
}

function formatMoneyInputValue(amount) {
  const numeric = Number(amount);
  if (!Number.isFinite(numeric)) {
    return "";
  }
  return (Math.round((numeric + Number.EPSILON) * 100) / 100).toFixed(2);
}

async function calculateDuty(event) {
  event.preventDefault();

  const value = parseCurrencyInput("dutyValue", "a valid vehicle value");
  const type = document.getElementById("dutyType").value;

  if (value === null) {
    return;
  }

  document.getElementById("dutyValue").value = formatMoneyInputValue(value);

  // We need CO2 for full calculation in backend, default to 0 if only calculating duty
  // But since VAT depends on Duty, and we might want to show VAT in the Tax form,
  // we should ideally have all data. For Duty form, we just care about Duty.

  try {
    const payload = {
      vehicle_value: value,
      category: type,
      co2_emissions: 0, // Not needed for pure Duty rate lookup in our schema usually, but logic might use it.
    };

    const result = await callCalculateApi(payload);
    if (result) {
      document.getElementById("dutyAmount").textContent = formatCurrency(
        result.importDuty
      );
      document.getElementById("dutyResult").classList.remove("hidden");
      updateGrandTotal(result.grandTotal);
    }
  } catch (e) {
    console.error(e);
  }
}

async function calculateTax(event) {
  event.preventDefault();

  const value = parseCurrencyInput("taxValue", "a valid vehicle value");
  const co2 = parseWholeNumberInput("taxCO2", "CO2 emissions");
  // Note: Fuel type isn't used in my simplified backend logic (just CO2), but in real life it is.
  // I will use proper values.

  // We need Vehicle Type to know the Duty Rate (which affects VAT base).
  // I'll grab it from the Duty form or vehicle state, defaulting to Car.
  const type = document.getElementById("dutyType").value || "Car";

  if (value === null || co2 === null) {
    return;
  }

  document.getElementById("taxValue").value = formatMoneyInputValue(value);

  try {
    const payload = {
      vehicle_value: value,
      category: type,
      co2_emissions: co2,
    };

    const result = await callCalculateApi(payload);
    if (result) {
      document.getElementById("vatAmount").textContent = formatCurrency(
        result.vat
      );
      document.getElementById("exciseAmount").textContent = formatCurrency(
        result.exciseDuty
      );
      document.getElementById("totalTaxAmount").textContent = formatCurrency(
        result.vat + result.exciseDuty
      );
      document.getElementById("taxResult").classList.remove("hidden");
      updateGrandTotal(result.grandTotal);
    }
  } catch (e) {
    console.error(e);
  }
}

async function callCalculateApi(payload) {
  try {
    const response = await fetch(`${API_BASE_URL}/calculate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-KEY": API_KEY,
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    if (response.ok) {
      return data;
    } else {
      alert(data.error || "Calculation failed");
      return null;
    }
  } catch (error) {
    alert("Server error");
    return null;
  }
}

function updateGrandTotal(total) {
  document.getElementById("grandTotalAmount").textContent =
    formatCurrency(total);
  document.getElementById("grandTotalCard").classList.remove("hidden");
}

function formatCurrency(amount) {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
  }).format(amount);
}

document.addEventListener("DOMContentLoaded", () => {
  ["dutyValue", "taxValue"].forEach((id) => {
    const input = document.getElementById(id);
    if (!input) return;

    input.addEventListener("blur", () => {
      const parsed = parseCurrencyInput(id, "a valid vehicle value", false);
      if (parsed !== null) {
        input.value = formatMoneyInputValue(parsed);
      }
    });
  });
});
